export CUR_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"/

mkdir build

./autogen.sh
./configure --with-mysql --without-pgsql --prefix=$CUR_DIR/build --exec-prefix=$CUR_DIR/build --with-mysql-includes=$CUR_DIR/../../inst/include --with-mysql-libs=$CUR_DIR/../../inst/lib

make -j
make install
