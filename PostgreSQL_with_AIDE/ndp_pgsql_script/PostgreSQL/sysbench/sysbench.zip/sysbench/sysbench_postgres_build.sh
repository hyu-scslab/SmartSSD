export CUR_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"/

mkdir build

./autogen.sh
./configure --without-mysql --with-pgsql --prefix=$CUR_DIR/build --exec-prefix=$CUR_DIR/build 

make -j
make install
